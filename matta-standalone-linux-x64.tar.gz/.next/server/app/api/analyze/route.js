var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/analyze/route.js")
R.c("server/chunks/[root-of-the-server]__1h8ahro._.js")
R.c("server/chunks/_10b5gsp._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5._.js")
R.c("server/chunks/_0la86ad._.js")
R.c("server/chunks/lib_corpus_ts_1wd7rrg._.js")
R.c("server/chunks/_next-internal_server_app_api_analyze_route_actions_0lx-23h.js")
R.m(78143)
module.exports=R.m(78143).exports
