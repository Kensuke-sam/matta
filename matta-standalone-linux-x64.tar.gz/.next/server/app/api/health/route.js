var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/health/route.js")
R.c("server/chunks/[root-of-the-server]__1sqn3yc._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5._.js")
R.c("server/chunks/lib_corpus_ts_1wd7rrg._.js")
R.c("server/chunks/_next-internal_server_app_api_health_route_actions_1ryftkb.js")
R.m(61370)
module.exports=R.m(61370).exports
